# PixelColab
To get started, run `npm install` to install dependencies

[Demo](http://pixel-colab.herokuapp.com)
/////////////